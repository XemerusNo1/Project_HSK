package entity;
public class DoanhThu {
    private int stt;
    private String thoigian;
    private double doanhThu;
	public DoanhThu(int stt, String thoigian, double doanhThu) {
		super();
		this.stt = stt;
		this.thoigian = thoigian;
		this.doanhThu = doanhThu;
	}
	public int getStt() {
		return stt;
	}
	public void setStt(int stt) {
		this.stt = stt;
	}


	public String getThoigian() {
		return thoigian;
	}
	public void setThoigian(String thoigian) {
		this.thoigian = thoigian;
	}
	public double getDoanhThu() {
		return doanhThu;
	}
	public void setDoanhThu(double doanhThu) {
		this.doanhThu = doanhThu;
	}
	@Override
	public String toString() {
		return "DoanhThu [stt=" + stt + ", thoigian=" + thoigian + ", doanhThu=" + doanhThu + "]";
	}

}
