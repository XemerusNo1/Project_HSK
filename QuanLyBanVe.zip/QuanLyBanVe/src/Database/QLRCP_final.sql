﻿-- Tạo cơ sở dữ liệu
USE [master];
GO
CREATE DATABASE QuanLyRapPhim;
GO
USE QuanLyRapPhim;
GO

-- Table Phim
CREATE TABLE Phim (
    maPhim VARCHAR(50) PRIMARY KEY,
    tenPhim NVARCHAR(255),
    theLoai NVARCHAR(255),
    daoDien VARCHAR(100),
    ThoiLuong INT,
    moTa NVARCHAR(MAX),
    linkAnh VARCHAR(255),
    giaphim DECIMAL(10, 2)
);
GO

-- Table Phong
CREATE TABLE Phong (
    maPhong VARCHAR(50) PRIMARY KEY,
    tongSoGhe INT
);
GO

-- Table ThoiGianChieu (Auto-generated primary key)
CREATE TABLE ThoiGianChieu (
    maGioChieu INT IDENTITY(1,1) PRIMARY KEY,
    maPhim VARCHAR(50),
    maPhong VARCHAR(50),
    GioChieu NVARCHAR(50),
	NgayChieu NVARCHAR(50),
    
    FOREIGN KEY (maPhim) REFERENCES Phim(maPhim),
    FOREIGN KEY (maPhong) REFERENCES Phong(maPhong)
);
GO


-- Table Ghe
CREATE TABLE Ghe (
    maGhe VARCHAR(50) PRIMARY KEY,
    maPhong VARCHAR(50),
    loaiGhe NVARCHAR(50),
    giaGhe DECIMAL(10, 2),
    FOREIGN KEY (maPhong) REFERENCES Phong(maPhong)
);
GO

-- Table NhanVien
CREATE TABLE NhanVien (
    maNV INT IDENTITY(1,1) PRIMARY KEY,
    tenNV NVARCHAR(255),
    namSinh INT, 
    sdt VARCHAR(15),
    gioiTinh BIT,
    tenTaiKhoan VARCHAR(80),
    matKhau VARCHAR(30)
);
GO
CREATE PROCEDURE sp_LayThongTinNhanVien
    @tenTaiKhoan VARCHAR(80)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT maNV, tenNV, namSinh, gioiTinh, sdt
    FROM dbo.NhanVien
    WHERE tenTaiKhoan = @tenTaiKhoan;
END;
GO
CREATE PROCEDURE doiMatKhau
    @tenTaiKhoan VARCHAR(80),
    @newPassword VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    -- Kiểm tra nếu tài khoản tồn tại
    IF EXISTS (SELECT 1 FROM dbo.NhanVien WHERE tenTaiKhoan = @tenTaiKhoan)
    BEGIN
        -- Cập nhật mật khẩu mới
        UPDATE dbo.NhanVien
        SET matKhau = @newPassword
        WHERE tenTaiKhoan = @tenTaiKhoan;

        -- Trả về kết quả thành công
        SELECT 1 AS result;
    END
    ELSE
    BEGIN
        -- Nếu không tìm thấy tài khoản, trả về thất bại
        SELECT 0 AS result;
    END
END;
GO
-- Table HoaDon (Auto-generated primary key)
CREATE TABLE HoaDon (
    maHoaDon INT IDENTITY(1,1) PRIMARY KEY,
    maNV INT NULL,
    tongTien DECIMAL(18, 2),
    ngayBan DATE,
    FOREIGN KEY (maNV) REFERENCES NhanVien(maNV)
);
GO
-- DELETE FROM ThoiGianChieu;
-- Table VePhim (Auto-generated primary key)
CREATE TABLE VePhim (
    maVe INT IDENTITY(1,1) PRIMARY KEY,
    maGioChieu INT,
    maHoaDon INT,
    giaVe DECIMAL(18, 2),
    SoLuongGheDaDat INT, 
    danhSachGhe VARCHAR(MAX),
    FOREIGN KEY (maGioChieu) REFERENCES ThoiGianChieu(maGioChieu),
    FOREIGN KEY (maHoaDon) REFERENCES HoaDon(maHoaDon)
);
GO

-- Table SanPham
CREATE TABLE SanPham (
    maSP VARCHAR(50) PRIMARY KEY,
    tenSP VARCHAR(100),
    giaBan DECIMAL(18, 2)
);
GO

-- Table SanPhamOrder (Auto-generated primary key)
CREATE TABLE SanPhamOrder (
    maOrderSP INT IDENTITY(1,1) PRIMARY KEY,
    maSP VARCHAR(50),
    maHoaDon INT,
    SoLuong INT,
    thanhTien DECIMAL(18, 2),
    FOREIGN KEY (maSP) REFERENCES SanPham(maSP),
    FOREIGN KEY (maHoaDon) REFERENCES HoaDon(maHoaDon)
);
GO

-- Table BaoCaoDoanhThu (Auto-generated primary key)
CREATE TABLE BaoCaoDoanhThu (
    maBaoCao INT IDENTITY(1,1) PRIMARY KEY,
    TongDoanhThu DECIMAL(18, 2),
    maNV INT,
    FOREIGN KEY (maNV) REFERENCES NhanVien(maNV)
);
GO

--- in insert dữ liêu và viết hàm store sau phần tạo table tránh có khả năng gây ra lỗi 
--insert dữ liệu viết ở đây
--DELETE FROM Phim;

GO
INSERT INTO Phim (maPhim, tenPhim,theLoai, daoDien, ThoiLuong, moTa,linkAnh,giaphim)
VALUES 
	(N'P01',N'Mộ Đom Đóm',		N'Hoạt hình',	N'Takahata Isao',89,		N'Hai anh em Seita và Setsuko mất mẹ sau cuộc thả bom dữ dội của \n\nkhông quân Mỹ. Cả hai phải vật lộn để tồn tại ở Nhật Bản hậu Thế chiến II. \n\nNhưng xã hội khắc nghiệt và chúng vật lộn tìm kiếm thức ăn cũng như \n\nthoát khỏi những khó khăn giữa chiến tranh.',N'src\\Images\\MoDomDom.jpg', 70000.00 ),
	(N'P02',	N'KUMANTHONG',	N'Kinh dị',		N'Xian Lim',121,	N'Sau cái chết của con trai, Sarah tìm đến vùng đất tâm linh Thái Lan, khẩn cần một thầy tu nổi tiếng sử dụng tro cốt đứa bé để tạo nên bức tượng Kumanthong. Bức tượng làm sống lại tình mẫu tử, nhưng triệu hồi những oan hồn ngạ quỷ đến đoạt xác cả gia đình Sarah.',N'src\\Images\\chieuhonvongnhi.jpg', 60000.00),
	(N'P05',	N'Qủy Ăn Tạng 2',	N'Kinh dị',		N'Taweewat Wantha',	143,	N'Ba năm sau cái chết của Yam, Yak vẫn tiếp tục săn lùng linh hồn bí ẩn mặc áo choàng đen. Gặp một cô gái có triệu chứng giống Yam, Yak phát hiện ra người bảo vệ linh hồn, pháp sư ẩn dật Puang, sống trong một khu rừng đầy nguy hiểm. Giữa những phép thuật ma quỷ và những sinh vật nguy hiểm...',N'src\\Images\\QuyAnTang1_2.jpg', 75000.00),
	(N'P06',	N'JOKER: FOLIE À DEUX',		N'Tâm lý',		N'Todd Phillips',123,		N'Joker: Folie à Deux" đưa Arthur Fleck đến trại tâm thần Arkham trong khi chờ xét xử cho những tội ác của hắn với tư cách là Joker. Trong lúc vật lộn với hai bản ngã của mình, Arthur không chỉ tìm thấy tình yêu đích thực mà còn khám phá ra âm nhạc luôn tồn tại trong con người hắn.',N'src\\Images\\Joker1_1.jpg', 80000.00),
	(N'P07',	N'CÁM - CHUYỆN CHƯA KỂ ',	N'Kinh dị',		N'Trần Hữu Tấn',	111,	N'Câu chuyện phim là dị bản kinh dị đẫm máu lấy cảm hứng từ truyện cổ tích nổi tiếng Tấm Cám, nội dung chính của phim xoay quanh Cám - em gái cùng cha khác mẹ của Tấm đồng thời sẽ có nhiều nhân vật và chi tiết sáng tạo, gợi cảm giác vừa lạ vừa quen cho khán giả.',N'src\\Images\\Cam1.jpg', 55000.00),
	(N'P03',	N'TRANSFORMERS MỘT',	N'Hoạt hình',	N'Josh Cooley',	113,		N'Câu chuyện về nguồn gốc chưa từng được hé lộ của Optimus Prime và Megatron. Hai nhân vật được biết đến như những kẻ thù truyền kiếp, nhưng cũng từng là những người anh em gắn bó, đã thay đổi vận mệnh của Cybertron mãi mãi.',N'src\\Images\\nguoimay1.jpg', 70000.00),
	(N'P09',	N'HAI MUỐI',	N'Tình cảm',	N'Josh Cooley',			118,	N'Muối – một cô gái mất mẹ từ khi vừa lọt lòng và lớn lên trong tình yêu thương của cha tại vùng đất xã đảo Thiềng Liềng. Bước ngoặt của hai cha con bắt đầu khi Muối trưởng thành, quyết định lên thành phố học tập và làm việc với ước mơ đổi đời để phụ giúp cha.',N'src\\Images\\MoDomDom.jpg', 65000.00),
	(N'P08',	N'VeNom',	N'Hoạt hình',	N'Kiyotaka Oshiyama',	98,		N'Eddie và Venom đang chạy trốn. Bị săn đuổi bởi kẻ thù từ cả hai thế giới của họ, cặp đôi buộc phải đưa ra một quyết định tàn khốc sẽ kết thúc điệu.',N'src\\Images\\Venom1.jpg', 50000.00),
	(N'P04',	N'Bạch Xà 3',		N'Hoạt hình',	N'Amp Wong và Zhao Ji',132,		N'Nam Tống Hàng Châu, tiểu Bạch tiểu Thanh tìm kiếm được a tuyên chuyển thế Hứa Tiên. Tiểu Bạch cùng Hứa Tiên cuối cùng thành vợ chồng. Hai người xây dựng bảo an đường trị bệnh cứu người, lại bị Pháp Hải nhìn thấu tiểu Bạch cùng tiểu Thanh yêu quái thân phận, muốn ngăn cản tiểu Bạch cùng Hứa Tiên cùng một chỗ',N'src\\Images\\BachXa3_1.jpg', 85000.00);
-- insert dữ liệu cho table phòng
Go
	INSERT INTO Phong (maPhong, tongSoGhe) VALUES 
	('Phong01', 50),
	('Phong02', 50),
	('Phong03', 50),
	('Phong04', 50),
	('Phong05', 50);
Go

INSERT INTO Ghe (maGhe, maPhong, loaiGhe, giaGhe) VALUES
    ('A01', 'Phong01', N'Ghế thường', 0.00),
    ('A02', 'Phong01', N'Ghế thường', 0.00),
    ('A03', 'Phong01', N'Ghế thường', 0.00),
    ('A04', 'Phong01', N'Ghế thường', 0.00),
    ('A05', 'Phong01', N'Ghế thường', 0.00),
    ('A06', 'Phong01', N'Ghế thường', 0.00),
    ('A07', 'Phong01', N'Ghế thường', 0.00),
    ('A08', 'Phong01', N'Ghế thường', 0.00),
    ('A09', 'Phong01', N'Ghế thường', 0.00),

    ('B01', 'Phong01', N'Ghế thường', 0.00),
    ('B02', 'Phong01', N'Ghế thường', 0.00),
    ('B03', 'Phong01', N'Ghế thường', 0.00),
    ('B04', 'Phong01', N'Ghế thường', 0.00),
    ('B05', 'Phong01', N'Ghế thường', 0.00),
    ('B06', 'Phong01', N'Ghế thường', 0.00),
    ('B07', 'Phong01', N'Ghế thường', 0.00),
    ('B08', 'Phong01', N'Ghế thường', 0.00),
    ('B09', 'Phong01', N'Ghế thường', 0.00),

    ('C01', 'Phong01', N'Ghế thường', 0.00),
    ('C02', 'Phong01', N'Ghế thường', 0.00),
    ('C03', 'Phong01', N'Ghế thường', 0.00),
    ('C04', 'Phong01', N'Ghế thường', 0.00),
    ('C05', 'Phong01', N'Ghế thường', 0.00),
    ('C06', 'Phong01', N'Ghế thường', 0.00),
    ('C07', 'Phong01', N'Ghế thường', 0.00),
    ('C08', 'Phong01', N'Ghế thường', 0.00),
    ('C09', 'Phong01', N'Ghế thường', 0.00),

    ('D01', 'Phong01', N'Ghế thường', 0.00),
    ('D02', 'Phong01', N'Ghế thường', 0.00),
    ('D03', 'Phong01', N'Ghế thường', 0.00),
    ('D04', 'Phong01', N'Ghế thường', 0.00),
    ('D05', 'Phong01', N'Ghế thường', 0.00),
    ('D06', 'Phong01', N'Ghế thường', 0.00),
    ('D07', 'Phong01', N'Ghế thường', 0.00),
    ('D08', 'Phong01', N'Ghế thường', 0.00),
    ('D09', 'Phong01', N'Ghế thường', 0.00),

    ('E01', 'Phong01', N'Ghế thường', 0.00),
    ('E02', 'Phong01', N'Ghế thường', 0.00),
    ('E03', 'Phong01', N'Ghế thường', 0.00),
    ('E04', 'Phong01', N'Ghế thường', 0.00),
    ('E05', 'Phong01', N'Ghế thường', 0.00),
    ('E06', 'Phong01', N'Ghế thường', 0.00),
    ('E07', 'Phong01', N'Ghế thường', 0.00),
    ('E08', 'Phong01', N'Ghế thường', 0.00),
    ('E09', 'Phong01', N'Ghế thường', 0.00),

    ('F01_Đôi', 'Phong01', N'Ghế Đôi', 50000.00),
    ('F02_Đôi', 'Phong01', N'Ghế Đôi', 50000.00),
    ('F03_Đôi', 'Phong01', N'Ghế Đôi', 50000.00),
    ('F04_Đôi', 'Phong01', N'Ghế Đôi', 50000.00),
    ('F05_Đôi', 'Phong01', N'Ghế Đôi', 50000.00);


Go
INSERT INTO SanPham (maSP, tenSP, giaBan) VALUES
	('SP01', N'Bắp caramel', 25000.00),
	('SP02', N'Bắp Phô mai', 25000.00),
	('SP03', N'Snack', 10000.00),
	('SP04', N'CoCaCoLa', 10000.00);

INSERT INTO HoaDon (maNV, tongTien, ngayBan)
	VALUES (NULL, 150000.00, '2024-11-05');


GO
-- store viết ở đây 
--store NhanVien
CREATE PROCEDURE sp_KiemTraDangNhap
    @tenTaiKhoan VARCHAR(80),
    @matKhau VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT * 
    FROM dbo.NhanVien
    WHERE tenTaiKhoan = @tenTaiKhoan AND matKhau = @matKhau;
END;
--store lấy dữ liệu phim lên thông tin phim

GO
CREATE PROCEDURE sp_LayTenPhimTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        tenPhim
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
--
GO
-- lấy Thể loại  
CREATE PROCEDURE sp_LayTheLoaiTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        theLoai
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
GO
-- lấy đạo diễn  
CREATE PROCEDURE sp_LayDaoDienTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        daoDien
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
GO
-- lấy Thời lượng  
CREATE PROCEDURE sp_LayThoiLuongTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        ThoiLuong
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
Go
-- lấy mo ta 
CREATE PROCEDURE sp_LayMoTaTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        moTa
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
GO
--Lấy link ảnh
CREATE PROCEDURE sp_LayLinkAnhTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        linkAnh
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
GO
-- lấy giá phim theo mã 
CREATE PROCEDURE sp_LayGiaPhimTheoMaPhim
    @maPhim VARCHAR(50)
AS
BEGIN
    SELECT 
        giaphim
    FROM 
        Phim
    WHERE 
        maPhim = @maPhim;
END;
GO
-- lấy giá ghế theo mã ghế
CREATE PROCEDURE sp_LayGiaGheTheoMaGhe
    @maGhe VARCHAR(50)
AS
BEGIN
    SELECT giaGhe FROM Ghe WHERE maGhe = @maGhe;
END;
GO
CREATE PROCEDURE GetDanhSachGhe 
    @maPhong VARCHAR(50),
    @GioChieu NVARCHAR(50),
    @NgayChieu NVARCHAR(50)
AS
BEGIN
    SELECT vp.danhSachGhe
    FROM VePhim vp
    JOIN ThoiGianChieu tg ON vp.maGioChieu = tg.maGioChieu
    WHERE tg.maPhong = @maPhong
      AND tg.GioChieu = @GioChieu
      AND tg.NgayChieu = @NgayChieu;
END;
GO

USE QuanLyRapPhim;
GO
SELECT ngayBan
FROM [QuanLyRapPhim].[dbo].[HoaDon]

SELECT GioChieu
FROM [QuanLyRapPhim].[dbo].[ThoiGianChieu];
GO

CREATE PROCEDURE laydoanhthucacnam
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        ROW_NUMBER() OVER (ORDER BY YEAR(ngayBan)) AS STT,
        YEAR(ngayBan) AS Nam,
        SUM(tongTien) AS DoanhThu
    FROM 
        HoaDon
    GROUP BY 
        YEAR(ngayBan);
END;
GO


CREATE PROCEDURE laydoanhthucacthang
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        ROW_NUMBER() OVER (ORDER BY MONTH(ngayBan)) AS STT,
        MONTH(ngayBan) AS Thang,
        @Year AS Nam,  
        SUM(tongTien) AS DoanhThu
    FROM 
        HoaDon
    WHERE 
        YEAR(ngayBan) = @Year
    GROUP BY 
        MONTH(ngayBan)
    ORDER BY 
        Thang;
END;
GO



CREATE PROCEDURE laydoanhthucacngaytrongthang
    @Year INT,
    @Month INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        ROW_NUMBER() OVER (ORDER BY DAY(ngayBan)) AS STT,
        CONVERT(VARCHAR(10), ngayBan, 103) AS Ngay, -- Định dạng ngày/tháng/năm
        SUM(tongTien) AS DoanhThu
    FROM 
        HoaDon
    WHERE 
        YEAR(ngayBan) = @Year AND MONTH(ngayBan) = @Month
    GROUP BY 
        ngayBan -- Nhóm theo ngày để có đầy đủ ngày/tháng/năm
    ORDER BY 
        ngayBan;
END;
GO





CREATE PROCEDURE Getdoanhthugiuacacngay
    @FromDate DATE,
    @ToDate DATE
AS
BEGIN
    SET NOCOUNT ON;

    SELECT 
        ROW_NUMBER() OVER (ORDER BY ngayBan) AS STT,
        ngayBan AS ThoiGian,
        SUM(tongTien) AS DoanhThu
    FROM 
        HoaDon
    WHERE 
        ngayBan BETWEEN @FromDate AND @ToDate
    GROUP BY 
        ngayBan
    ORDER BY 
        ngayBan;
END;
GO

