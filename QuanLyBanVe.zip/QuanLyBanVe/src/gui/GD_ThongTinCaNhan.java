package gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;

import dao.DAO_ThongTinNhanVien;
import entity.NhanVien;

public class GD_ThongTinCaNhan extends JPanel {
    private JLabel title;
    private Font font;
    private JLabel txtmanv;  
    private JLabel txtnamsinh; 
    private JLabel txtgioitinh; 
    private JLabel txtten; 
    private JLabel txtsdt; 
    private JPanel pnn;  // Use this as the main container panel

    public GD_ThongTinCaNhan(String tenTaiKhoan) {
        setSize(1100, 700);
        setBackground(Color.WHITE);

        // Initialize pnn as the main panel
        pnn = new JPanel();
        pnn.setLayout(new BorderLayout()); 
        pnn.setBackground(Color.WHITE);

        // Create title
        title = new JLabel("THÔNG TIN NHÂN VIÊN", SwingConstants.CENTER);
        font = new Font("Times New Roman", Font.BOLD, 40);
        title.setFont(font);
        title.setForeground(Color.BLACK);
        pnn.add(title, BorderLayout.NORTH); 

        // Add separator
        JSeparator separator = new JSeparator();
        separator.setPreferredSize(new Dimension(800, 2));
        separator.setBackground(Color.BLACK);
        separator.setOpaque(true);

        JPanel separatorPanel = new JPanel();
        separatorPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 50, 0));
        separatorPanel.add(separator);
        separatorPanel.setBackground(Color.WHITE);
        pnn.add(separatorPanel, BorderLayout.NORTH);

        // Main panel with employee details
        JPanel mainPanel = new JPanel(new GridLayout(1, 2));
        JPanel leftPanel = new JPanel();
        ImageIcon oricon = new ImageIcon("src\\Images\\profile.png");

        // Resize icon
        Image icon = oricon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        ImageIcon iconchart = new ImageIcon(icon);

        JLabel iconLabel = new JLabel(iconchart);
        iconLabel.setBorder(BorderFactory.createEmptyBorder(30, 0, 0, 200));
        leftPanel.add(iconLabel);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setAlignmentX(Component.LEFT_ALIGNMENT);

        Font font1 = new Font("Times New Roman", Font.PLAIN, 20);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 50)));

        // Employee info
        rightPanel.add(createLabelValuePair("Mã Nhân Viên:", txtmanv = new JLabel(), font1));
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(createLabelValuePair("Tên Nhân Viên:", txtten = new JLabel(), font1));
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(createLabelValuePair("Năm Sinh:", txtnamsinh = new JLabel(), font1));
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(createLabelValuePair("Giới tính:", txtgioitinh = new JLabel(), font1));
        rightPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        rightPanel.add(createLabelValuePair("Số Điện Thoại:", txtsdt = new JLabel(), font1));

        rightPanel.setBackground(Color.WHITE);
        leftPanel.setBackground(Color.WHITE);
        mainPanel.add(leftPanel);
        mainPanel.add(rightPanel);
        pnn.add(mainPanel, BorderLayout.CENTER);

        // Add south section for change password button
        JPanel pns = new JPanel();
        pns.setLayout(new BorderLayout());

        JSeparator separator1 = new JSeparator();
        separator1.setPreferredSize(new Dimension(800, 2));
        separator1.setBackground(Color.BLACK);
        separator1.setOpaque(true);

        JPanel separatorPanel1 = new JPanel();
        separatorPanel1.setLayout(new FlowLayout(FlowLayout.LEFT, 50, 0));
        separatorPanel1.add(separator1);
        separatorPanel1.setBackground(Color.WHITE);
        pns.add(separatorPanel1, BorderLayout.NORTH);

        JPanel southPanel = new JPanel();
        southPanel.setLayout(new BoxLayout(southPanel, BoxLayout.Y_AXIS));
        southPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnDoiMatKhau = new JButton("Đổi Mật Khẩu");
        btnDoiMatKhau.setPreferredSize(new Dimension(150, 40));
        btnDoiMatKhau.setAlignmentX(Component.CENTER_ALIGNMENT);

        southPanel.add(Box.createVerticalGlue());
        southPanel.add(btnDoiMatKhau);
        southPanel.add(Box.createVerticalGlue());

        pns.add(southPanel);
        pnn.add(pns, BorderLayout.SOUTH);

        add(pnn);  // Add the main pnn panel to this JPanel

        loadEmployeeData(tenTaiKhoan);

        btnDoiMatKhau.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadPanel(new GD_DoiMatKhau(tenTaiKhoan));
            }
        });
    }

    private JPanel createLabelValuePair(String labelText, JLabel valueLabel, Font font) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        panel.setBackground(Color.WHITE);
        
        JLabel label = new JLabel(labelText);
        label.setFont(font);
        label.setForeground(Color.BLACK);
        
        valueLabel.setFont(font);
        valueLabel.setForeground(Color.BLACK);
        
        valueLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

        panel.add(label);
        panel.add(valueLabel);
        
        return panel;
    }

    private void loadEmployeeData(String tenTaiKhoan) {
        DAO_ThongTinNhanVien dao = new DAO_ThongTinNhanVien();
        NhanVien nhanVien = dao.layThongTinNhanVien(tenTaiKhoan);
        if (nhanVien != null) {
            txtmanv.setText(String.valueOf(nhanVien.getMaNV()));
            txtten.setText(nhanVien.getTenNV());
            txtnamsinh.setText(nhanVien.getNamSinh());
            txtgioitinh.setText(nhanVien.isGioiTinh() ? "Nam" : "Nữ");
            txtsdt.setText(nhanVien.getSdt());
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin nhân viên.", "Thông báo", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void loadPanel(JPanel panel) {
        pnn.removeAll();
        pnn.add(panel, BorderLayout.CENTER);
        pnn.revalidate();
        pnn.repaint();
    }
}
