package gui;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import dao.DAO_ThongTinPhim;
import dao.DAO_TimPhim;
import dulieutamthoi.ThongTinDatVe;
import entity.Phim;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class GD_TimPhim extends JPanel implements ActionListener {
    private JTextField textTimPhim;
    private JTable tablePhim;
    private DefaultTableModel tableModel;
    private DAO_TimPhim daoTimPhim;
	private JPanel contentPane;
    public GD_TimPhim() {
        // Configure the main window
        setLayout(new BorderLayout(0, 0));
        setBounds(100, 100, 1100, 700);
        
        contentPane = new JPanel();
        contentPane.setBackground(new Color(64, 64, 64));
        contentPane.setBorder(new EmptyBorder(0, 0, 0, 0));
        add(contentPane, BorderLayout.CENTER);
        contentPane.setLayout(new BorderLayout(0, 0));
        
        JPanel pnlNorth = new JPanel();
        pnlNorth.setBackground(new Color(240, 240, 240));
        pnlNorth.setPreferredSize(new Dimension(1000, 50));
        pnlNorth.setBorder(new MatteBorder(0, 0, 1, 0, Color.BLACK));
        contentPane.add(pnlNorth, BorderLayout.NORTH);

        JLabel lblDS = new JLabel("Danh sách phim");
        lblDS.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblDS.setIcon(new ImageIcon("src\\Images\\list.png"));
        lblDS.setForeground(Color.BLACK);
        
        JLabel lblNewLabel = new JLabel("Tìm kiếm phim:");
        lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNewLabel.setForeground(Color.BLACK);
        
        textTimPhim = new JTextField();
        textTimPhim.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        textTimPhim.setColumns(10);
        
        JButton btnTimPhim = new JButton("Tìm");
        btnTimPhim.setFont(new Font("Times New Roman", Font.BOLD, 17));
        
        // Layout for north panel
        GroupLayout gl_pnlNorth = new GroupLayout(pnlNorth);
        gl_pnlNorth.setHorizontalGroup(
            gl_pnlNorth.createParallelGroup(Alignment.LEADING)
                .addGroup(gl_pnlNorth.createSequentialGroup()
                    .addGap(26)
                    .addComponent(lblDS)
                    .addPreferredGap(ComponentPlacement.RELATED, 476, Short.MAX_VALUE)
                    .addComponent(lblNewLabel)
                    .addGap(32)
                    .addComponent(textTimPhim, GroupLayout.PREFERRED_SIZE, 166, GroupLayout.PREFERRED_SIZE)
                    .addGap(18)
                    .addComponent(btnTimPhim)
                    .addGap(143))
        );
        gl_pnlNorth.setVerticalGroup(
            gl_pnlNorth.createParallelGroup(Alignment.LEADING)
                .addGroup(gl_pnlNorth.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(gl_pnlNorth.createParallelGroup(Alignment.BASELINE)
                        .addComponent(lblDS)
                        .addComponent(textTimPhim, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblNewLabel)
                        .addComponent(btnTimPhim))
                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnlNorth.setLayout(gl_pnlNorth);

        // Initialize components
        daoTimPhim = new DAO_TimPhim();
        tableModel = new DefaultTableModel(new String[]{"Mã Phim", "Tên Phim", "Thể Loại", "Đạo Diễn", "Thời Lượng", "Mô Tả", "Giá Phim", "Đặt Vé"}, 0);
        tablePhim = new JTable(tableModel);
        tablePhim.setRowHeight(30);

        // Set the button renderer and editor for the last column
        tablePhim.getColumnModel().getColumn(7).setCellRenderer(new ButtonRenderer());
        tablePhim.getColumnModel().getColumn(7).setCellEditor(new ButtonEditor(new JCheckBox()));

        // Place the JTable inside a JScrollPane
        JScrollPane tableScrollPane = new JScrollPane(tablePhim);
        contentPane.add(tableScrollPane, BorderLayout.CENTER);

        // Load all movie data initially
        // daoTimPhim.LoadDataToArrayList();
        // daoTimPhim.LoadDataArrayListToTable(tableModel);
        
        textTimPhim.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                tablePhim.setVisible(true); // Show the table when the field gains focus
            }
        });

        // Real-time search on key release
        textTimPhim.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                String tuKhoa = textTimPhim.getText().trim();
                if (!tuKhoa.isEmpty()) {
                    daoTimPhim.timTenPhim(tuKhoa, tableModel);
                } else {
                    // If search field is empty, load all data
                    // daoTimPhim.LoadDataToArrayList();
                    // daoTimPhim.LoadDataArrayListToTable(tableModel);
                }
            }
        });
        
        // Button action for searching
        btnTimPhim.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tuKhoa = textTimPhim.getText().trim();
                if (!tuKhoa.isEmpty()) {
                    daoTimPhim.timTenPhim(tuKhoa, tableModel);
                } else {
                    // Load all data if search field is empty
                    // daoTimPhim.LoadDataToArrayList();
                    // daoTimPhim.LoadDataArrayListToTable(tableModel);
                }
            }
        });
    }

    // Button renderer to display buttons in the table
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText("Đặt vé");
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    // Button editor to handle button actions
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private boolean isPushed;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int row = tablePhim.getSelectedRow(); // Lấy chỉ số hàng được chọn
                    
                    if (row >= 0) {
                    	String maPhim = (String) tablePhim.getValueAt(row, 0); // Giả sử cột 0 là mã phim

                        // Lưu mã phim vào ThongTinDatVe
                        ThongTinDatVe.setMaPhim(maPhim);

                        // Sau khi lấy mã phim, gọi hàm lấy thông tin phim từ cơ sở dữ liệu
                        DAO_ThongTinPhim dao = new DAO_ThongTinPhim();
                        String tenPhim = dao.getTenPhimByMaPhim(maPhim);
                        String daoDien = dao.getDaoDienByMaPhim(maPhim);
                        String theLoai = dao.getTheLoaiByMaPhim(maPhim);
                        String thoiLuong = dao.getThoiLuongByMaPhim(maPhim);
                        String moTa = dao.getMoTaByMaPhim(maPhim);

                        // Mở giao diện thông tin phim và hiển thị thông tin
                        GD_ThongTinPhim thongTinPhim = new GD_ThongTinPhim();
                        thongTinPhim.layThongTinPhim();
                        thongTinPhim.setVisible(true);
                        loadPanel(thongTinPhim);
                    } else {
                        JOptionPane.showMessageDialog(button, "Vui lòng chọn một phim để đặt vé!"); // Thông báo khi không có hàng nào được chọn
                    }
                    isPushed = true;
                    fireEditingStopped(); // Dừng chỉnh sửa khi nút được nhấn
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            button.setText("Đặt vé");
            isPushed = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            isPushed = false;
            return null; // Không cần trả về giá trị gì
        }

        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }
    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> {
//            JFrame frame = new JFrame("Tìm Kiếm Phim");
//            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//            frame.setSize(1100, 700);
//            frame.setLocationRelativeTo(null);
//            frame.setContentPane(new PhimGUI());
//            frame.setVisible(true);
//        });
//    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Action handling can be implemented here if needed
    }
    private void loadPanel(JPanel panel) {
	    contentPane.removeAll();
	    contentPane.add(panel, BorderLayout.CENTER);
	    contentPane.validate();
	    contentPane.repaint();
	}
}
