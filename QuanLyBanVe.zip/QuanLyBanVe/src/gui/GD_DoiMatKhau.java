package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;

import dao.DAO_DangNhap;
import dao.DAO_DoiMatKhau;

public class GD_DoiMatKhau extends JPanel {
    private DAO_DangNhap daoDangNhap;
    private Image backgroundImage;
    private JTextField txtMKCu;
    private JPasswordField txtMKMoi;
    private JPasswordField txtXnMKMoi;
    private JButton btnDoiMatKhau;
    private String tenTaiKhoan;
    private JPanel contentPanel;

    public GD_DoiMatKhau(String tenTaiKhoan) {
        this.tenTaiKhoan = tenTaiKhoan;
        setSize(1100, 700);
        setLayout(new BorderLayout());
        backgroundImage = new ImageIcon("src\\Images\\background.png").getImage(); // Đảm bảo đường dẫn tới ảnh là đúng

        contentPanel = new JPanel();
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setLayout(new GridBagLayout()); // Sử dụng GridBagLayout

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new java.awt.Insets(10, 10, 10, 10); // Khoảng cách giữa các thành phần

        // Mật khẩu cũ
        JLabel lblMKCu = new JLabel("Nhập mật khẩu cũ:", SwingConstants.CENTER);
        lblMKCu.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblMKCu.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2; // Chiếm 2 cột để căn giữa
        contentPanel.add(lblMKCu, gbc);

        txtMKCu = new JTextField(40); // Chiều rộng ô nhập liệu là 40 ký tự
        txtMKCu.setPreferredSize(new java.awt.Dimension(200, 40));  // Đặt chiều rộng và chiều cao cho ô nhập liệu
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2; // Ô nhập liệu chiếm 2 cột
        gbc.fill = GridBagConstraints.HORIZONTAL; // Làm cho TextField chiếm hết không gian còn lại
        contentPanel.add(txtMKCu, gbc);

        // Mật khẩu mới
        JLabel lblMKMoi = new JLabel("Nhập mật khẩu mới:", SwingConstants.CENTER);
        lblMKMoi.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblMKMoi.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2; // Chiếm 2 cột để căn giữa
        contentPanel.add(lblMKMoi, gbc);

        txtMKMoi = new JPasswordField(40);
        txtMKMoi.setPreferredSize(new java.awt.Dimension(200, 40));  // Đặt chiều rộng và chiều cao cho ô nhập liệu
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 2; // Ô nhập liệu chiếm 2 cột
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(txtMKMoi, gbc);

        // Xác nhận mật khẩu mới
        JLabel lblXnMKMoi = new JLabel("Xác nhận mật khẩu mới:", SwingConstants.CENTER);
        lblXnMKMoi.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblXnMKMoi.setForeground(Color.BLACK);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Chiếm 2 cột để căn giữa
        contentPanel.add(lblXnMKMoi, gbc);

        txtXnMKMoi = new JPasswordField(40);
        txtXnMKMoi.setPreferredSize(new java.awt.Dimension(200, 40));  // Đặt chiều rộng và chiều cao cho ô nhập liệu
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2; // Ô nhập liệu chiếm 2 cột
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(txtXnMKMoi, gbc);

        // Nút Đổi mật khẩu
        btnDoiMatKhau = new JButton("Đổi mật khẩu");
        btnDoiMatKhau.setFont(new Font("Times New Roman", Font.BOLD, 20));
        btnDoiMatKhau.setBackground(Color.BLACK);
        btnDoiMatKhau.setForeground(Color.WHITE);
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2; // Nút chiếm 2 cột để căn giữa
        gbc.fill = GridBagConstraints.HORIZONTAL;
        contentPanel.add(btnDoiMatKhau, gbc);

        add(contentPanel, BorderLayout.CENTER);

        // Xử lý đổi mật khẩu
        btnDoiMatKhau.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String matKhauCu = new String(txtMKCu.getText()).trim();
                String matKhauMoi = new String(txtMKMoi.getPassword()).trim();
                String matKhauXacNhan = new String(txtXnMKMoi.getPassword()).trim();

                if (matKhauCu.isEmpty() || matKhauMoi.isEmpty() || matKhauXacNhan.isEmpty()) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Vui lòng điền đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (!matKhauMoi.equals(matKhauXacNhan)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu mới và xác nhận không khớp!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (matKhauCu.equals(matKhauMoi)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu mới không thể giống mật khẩu cũ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                DAO_DangNhap daoKTMK = new DAO_DangNhap();
                DAO_DoiMatKhau daoDoiMatKhau = new DAO_DoiMatKhau();
                if (!daoKTMK.kiemTraDangNhap(tenTaiKhoan, matKhauCu)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu cũ không chính xác!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (daoDoiMatKhau.doiMatKhau(tenTaiKhoan, matKhauMoi)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Đổi mật khẩu thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    
                    new GD_DangNhap().setVisible(true);
                    JFrame parentFrame = (JFrame) SwingUtilities.getWindowAncestor(GD_DoiMatKhau.this);
                    if (parentFrame != null) {
                        parentFrame.dispose();
                    }
                } else {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Đã có lỗi xảy ra khi đổi mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);  // Vẽ hình ảnh lên JPanel
    }
}
