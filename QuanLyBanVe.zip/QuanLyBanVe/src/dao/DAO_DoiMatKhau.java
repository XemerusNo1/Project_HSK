package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import connection.MyConnection;

public class DAO_DoiMatKhau {
    private Connection conn;

    public DAO_DoiMatKhau() {
        conn = MyConnection.getInstance().getConnection();
    }

    // Thực hiện thay đổi mật khẩu mới
    public boolean doiMatKhau(String tenTaiKhoan, String matKhauMoi) {
        String sql = "{call doiMatKhau(?, ?)}"; // Gọi stored procedure
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenTaiKhoan);  // Đặt tên tài khoản vào tham số
            ps.setString(2, matKhauMoi);   // Đặt mật khẩu mới vào tham số

            ResultSet rs = ps.executeQuery(); // Thực thi stored procedure
            if (rs.next()) {
                int result = rs.getInt("result");
                return result == 1;  // Nếu result = 1, trả về true (thành công)
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
