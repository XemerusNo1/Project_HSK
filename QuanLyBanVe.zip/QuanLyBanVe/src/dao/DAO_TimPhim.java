package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import connection.MyConnection;
import entity.Phim;

public class DAO_TimPhim {
    private Connection conn;
    private ArrayList<Phim> arr;

    public DAO_TimPhim() {
        conn = MyConnection.getInstance().getConnection();
        arr = new ArrayList<>();
    }

    // Load tất cả dữ liệu từ cơ sở dữ liệu vào ArrayList
    public void LoadDataToArrayList() {
        arr.clear();
        try {
            String sql = "SELECT * FROM Phim";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maPhim = rs.getString(1);
                String tenPhim = rs.getString(2);
                String theLoai = rs.getString(3);
                String daoDien = rs.getString(4);
                int thoiLuong = rs.getInt(5);
                String moTa = rs.getString(6);
                Double giaPhim = rs.getDouble(8);

                Phim phim = new Phim(maPhim, tenPhim, theLoai, daoDien, thoiLuong, moTa, giaPhim);
                arr.add(phim);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load dữ liệu từ ArrayList vào JTable
    public void LoadDataArrayListToTable(DefaultTableModel tableModel) {
        tableModel.setRowCount(0); // Xóa dữ liệu cũ
        for (Phim phim : arr) {
            tableModel.addRow(new Object[]{
                phim.getMaPhim(),
                phim.getTieuDe(),
                phim.getTheLoai(),
                phim.getDaoDien(),
                phim.getThoiLuong(),
                phim.getMoTa(),
                phim.getGiaPhim()
            });
        }
    }

    // Tìm phim theo tên và cập nhật ArrayList, sau đó load vào JTable
    public void timTenPhim(String tenPhimCanTim, DefaultTableModel tableModel) {
        arr.clear();
        try {
            String sql = "SELECT * FROM Phim WHERE tenPhim LIKE ?";
            PreparedStatement st = conn.prepareStatement(sql);
            st.setString(1, "%" + tenPhimCanTim + "%");
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                String maPhim = rs.getString(1);
                String tenPhim = rs.getString(2);
                String theLoai = rs.getString(3);
                String daoDien = rs.getString(4);
                int thoiLuong = rs.getInt(5);
                String moTa = rs.getString(6);
                Double giaPhim = rs.getDouble(8);

                Phim phim = new Phim(maPhim, tenPhim, theLoai, daoDien, thoiLuong, moTa, giaPhim);
                arr.add(phim);
            }
            LoadDataArrayListToTable(tableModel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    
}
