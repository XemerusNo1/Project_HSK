package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import connection.MyConnection;
import entity.NhanVien;

public class DAO_ThongTinNhanVien {
    private Connection conn;

    public DAO_ThongTinNhanVien() {
        conn = MyConnection.getInstance().getConnection();
    }

    // Method to retrieve employee information using a stored procedure
    public NhanVien layThongTinNhanVien(String tenTaiKhoan) {
        String sql = "{CALL sp_LayThongTinNhanVien(?)}";
        NhanVien nhanVien = null;

        try (CallableStatement stmt = conn.prepareCall(sql)) {
            stmt.setString(1, tenTaiKhoan);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int maNV = rs.getInt("maNV");
                String tenNV = rs.getString("tenNV");
                String namSinh = rs.getString("namSinh");
                boolean gioiTinh = rs.getBoolean("gioiTinh");
                String sdt = rs.getString("sdt");

                // Create a new NhanVien object with the retrieved details
                nhanVien = new NhanVien(maNV, tenNV, namSinh, sdt, gioiTinh,null,null);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle exception
        }

        return nhanVien; // Return the NhanVien object or null if not found
    }
}
