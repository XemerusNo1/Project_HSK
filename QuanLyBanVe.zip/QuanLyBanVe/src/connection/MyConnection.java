package connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnection {
    private static MyConnection instance;
    private Connection connection;

    private MyConnection() {
        connect();
    }

    private void connect() {
        String url = "jdbc:sqlserver://localhost:1433;DatabaseName=QuanLyRapPhim;encrypt=true;trustServerCertificate=true";
        String user = "sa";
        String password = "123";

        try {
            connection = DriverManager.getConnection(url, user, password);
            System.out.println("Kết nối database thành công");
        } catch (SQLException e1) {
            System.out.println("Kết nối database không thành công");
            e1.printStackTrace();
        }
    }

    public synchronized static MyConnection getInstance() {
        if (instance == null) {
            instance = new MyConnection();
        }
        return instance;
    }

    public Connection getConnection() {
        // Kiểm tra nếu kết nối đã bị đóng
        try {
            if (connection == null || connection.isClosed()) {
                connect(); // Tạo lại kết nối
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Có thể ghi log hoặc thông báo lỗi
        }
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Kết nối đã được đóng.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
