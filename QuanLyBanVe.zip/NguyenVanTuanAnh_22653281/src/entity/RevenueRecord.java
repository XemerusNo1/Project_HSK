package entity;
public class RevenueRecord {
//    private String time;
//    private double revenue;
    private int stt;
    private String thoigian;
    private double doanhThu;
//    public RevenueRecord(String time, double revenue) {
//        this.time = time;
//        this.revenue = revenue;
//    }
	public RevenueRecord(int stt, String thoigian, double doanhThu) {
		super();
		this.stt = stt;
		this.thoigian = thoigian;
		this.doanhThu = doanhThu;
	}
	public int getStt() {
		return stt;
	}
	public void setStt(int stt) {
		this.stt = stt;
	}


	public String getThoigian() {
		return thoigian;
	}
	public void setThoigian(String thoigian) {
		this.thoigian = thoigian;
	}
	public double getDoanhThu() {
		return doanhThu;
	}
	public void setDoanhThu(double doanhThu) {
		this.doanhThu = doanhThu;
	}
	@Override
	public String toString() {
		return "RevenueRecord [stt=" + stt + ", thoigian=" + thoigian + ", doanhThu=" + doanhThu + "]";
	}

//	public String getTime() {
//        return time;
//    }
//
//    public double getRevenue() {
//        return revenue;
//    }
}
