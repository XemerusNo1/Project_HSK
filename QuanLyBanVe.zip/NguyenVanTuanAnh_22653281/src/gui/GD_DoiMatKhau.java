package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import dao.DAO_DangNhap;
import dao.DAO_DoiMatKhau;


public class GD_DoiMatKhau extends JFrame {
	private DAO_DangNhap daoDangNhap;
    private Image backgroundImage;
    private JButton btnDangNhap, btnDangKy;
	private JTextField txtDangNhap;
	private Connection connection;
	private JPasswordField txtMatKhau;
	private JTextField txtMKCu;
	private JPasswordField txtMKMoi;
	private JPasswordField txtXnMKMoi;
	private JButton btnDoiMatKhau;
	private String tenTaiKhoan;
    
//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            try {
//                GD_DoiMatKhau frame = new GD_DoiMatKhau();
//                frame.setVisible(true);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//        });
//    }

    public GD_DoiMatKhau(String tenTaiKhoan) {
    	this.tenTaiKhoan = tenTaiKhoan; 
        setSize(1100, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setTitle("Đổi Mật Khẩu");

        backgroundImage = new ImageIcon("src\\Images\\background-dang-nhap.png").getImage();
        BackgroundPanel backgroundPanel = new BackgroundPanel();
        setContentPane(backgroundPanel);
        backgroundPanel.setLayout(null);
        System.out.println("Tên tài khoản: " + tenTaiKhoan);
        // Mật khẩu cũ
        JLabel lblMKCu = new JLabel("Nhập mật khẩu cũ:", SwingConstants.CENTER);
        lblMKCu.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblMKCu.setForeground(Color.BLACK);
        lblMKCu.setBounds(230, 230, 400, 40); // Cập nhật chiều rộng 150px
        txtMKCu = new JTextField();
        txtMKCu.setBounds(400, 270, 300, 40); // Đặt ô nhập liệu ở bên phải với chiều rộng 300px

        // Mật khẩu mới
        JLabel lblMKMoi = new JLabel("Nhập mật khẩu mới:", SwingConstants.CENTER);
        lblMKMoi.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblMKMoi.setForeground(Color.BLACK);
        lblMKMoi.setBounds(230, 305, 400, 40); // Cập nhật chiều rộng 150px
        txtMKMoi = new JPasswordField();
        txtMKMoi.setBounds(400, 340, 300, 40);
        // Xác nhân mật khẩu mới
        JLabel lblXnMKMoi = new JLabel("Xác nhận mật khẩu mới:", SwingConstants.CENTER);
        lblXnMKMoi.setFont(new Font("Times New Roman", Font.BOLD, 15));
        lblXnMKMoi.setForeground(Color.BLACK);
        lblXnMKMoi.setBounds(240, 380, 400, 40);
        txtXnMKMoi = new JPasswordField();
        txtXnMKMoi.setBounds(400, 420, 300, 40);
        
        // nút Đăng nhập
        btnDoiMatKhau = new JButton("Đổi mật khẩu");
        btnDoiMatKhau.setFont(new Font("Times New Roman", Font.BOLD, 15));
        btnDoiMatKhau.setBackground(Color.BLACK);
        btnDoiMatKhau.setForeground(Color.WHITE);
        btnDoiMatKhau.setBounds(550, 500, 150, 40);
        
        // nút Đăng ký

        
        backgroundPanel.add(lblMKCu);
        backgroundPanel.add(txtMKCu);
        backgroundPanel.add(lblMKMoi);
        backgroundPanel.add(txtMKMoi);
        backgroundPanel.add(lblXnMKMoi);
        backgroundPanel.add(txtXnMKMoi);
        backgroundPanel.add(btnDoiMatKhau);
        

// xử lý đổi mật khẩu
     // Nút Đổi mật khẩu
     // Nút Đổi mật khẩu
        btnDoiMatKhau.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String matKhauCu = new String(txtMKCu.getText()).trim();
                String matKhauMoi = new String(txtMKMoi.getPassword()).trim();
                String matKhauXacNhan = new String(txtXnMKMoi.getPassword()).trim();

                // Kiểm tra các trường mật khẩu có trống không
                if (matKhauCu.isEmpty() || matKhauMoi.isEmpty() || matKhauXacNhan.isEmpty()) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Vui lòng điền đầy đủ thông tin!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Kiểm tra mật khẩu mới và xác nhận có giống nhau không
                if (!matKhauMoi.equals(matKhauXacNhan)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu mới và xác nhận không khớp!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Kiểm tra mật khẩu mới có giống mật khẩu cũ không
                if (matKhauCu.equals(matKhauMoi)) {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu mới không thể giống mật khẩu cũ!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Tạo đối tượng daoDoiMatKhau và kiểm tra mật khẩu cũ
                DAO_DangNhap daoKTMK = new DAO_DangNhap();
                DAO_DoiMatKhau daoDoiMatKhau = new DAO_DoiMatKhau(); // Tạo đối tượng của lớp DAO_DoiMatKhau
                if (!daoKTMK.kiemTraDangNhap(tenTaiKhoan, matKhauCu)) {  // Kiểm tra mật khẩu cũ
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Mật khẩu cũ không chính xác!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Gọi phương thức đổi mật khẩu
                if (daoDoiMatKhau.doiMatKhau(tenTaiKhoan, matKhauMoi)) {  // Gọi phương thức từ đối tượng để thay đổi mật khẩu
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Đổi mật khẩu thành công!", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
                    dispose();  // Đóng cửa sổ đổi mật khẩu
                    //new GD_DangNhap().setVisible(true); // Mở lại cửa sổ đăng nhập
                } else {
                    JOptionPane.showMessageDialog(GD_DoiMatKhau.this, "Đã có lỗi xảy ra khi đổi mật khẩu!", "Lỗi", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


    }
    
    private class BackgroundPanel extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }

}
